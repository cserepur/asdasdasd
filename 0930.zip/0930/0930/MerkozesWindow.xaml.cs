﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.IO;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace _0930
{
    /// <summary>
    /// Interaction logic for MerkozesWindow.xaml
    /// </summary>
    public partial class MerkozesWindow : Window
    {
        private const string MatchesFile = "matches.txt";
        private const string TeamsFile = "teams.txt";

        public MerkozesWindow()
        {
            InitializeComponent();
            BetoltCsapatok();
            BetoltMerkozesek();
        }

        private void BetoltCsapatok()
        {
            if (File.Exists(TeamsFile))
            {
                List<string> csapatok = new List<string>(File.ReadAllLines(TeamsFile));
                cbCsapat1.ItemsSource = csapatok;
                cbCsapat2.ItemsSource = csapatok;
                if (csapatok.Count > 0)
                {
                    cbCsapat1.SelectedIndex = 0;
                    if (csapatok.Count > 1)
                        cbCsapat2.SelectedIndex = 1;
                }
            }
        }

        private void MentesButton_Click(object sender, RoutedEventArgs e)
        {
            string csapat1 = cbCsapat1.SelectedItem?.ToString();
            string csapat2 = cbCsapat2.SelectedItem?.ToString();
            string eredmeny1 = txtEredmeny1.Text.Trim();
            string eredmeny2 = txtEredmeny2.Text.Trim();

            if (!string.IsNullOrEmpty(csapat1) && !string.IsNullOrEmpty(csapat2) &&
                !string.IsNullOrEmpty(eredmeny1) && !string.IsNullOrEmpty(eredmeny2))
            {
                string merkozesAdat = $"{csapat1};{eredmeny1};{csapat2};{eredmeny2}";
                File.AppendAllText(MatchesFile, merkozesAdat + "\n");
                BetoltMerkozesek();
                MessageBox.Show("Mérkőzés eredmény mentve!");
            }
        }

        private void BetoltButton_Click(object sender, RoutedEventArgs e)
        {
            BetoltMerkozesek();
        }

        private void BetoltMerkozesek()
        {
            if (File.Exists(MatchesFile))
            {
                List<string> merkozesek = new List<string>(File.ReadAllLines(MatchesFile));
                lbMerkozesek.ItemsSource = merkozesek;
            }
        }

        private void BezarButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
