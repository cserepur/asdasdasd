﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.IO;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace _0930
{
    /// <summary>
    /// Interaction logic for CsapattagokWindow.xaml
    /// </summary>
    public partial class CsapattagokWindow : Window
    {
        private const string PlayersFile = "players.txt";
        private const string TeamsFile = "teams.txt";

        public CsapattagokWindow()
        {
            InitializeComponent();
            BetoltCsapatok();
            BetoltJatekosok();
        }

        private void BetoltCsapatok()
        {
            if (File.Exists(TeamsFile))
            {
                List<string> csapatok = new List<string>(File.ReadAllLines(TeamsFile));
                cbCsapatok.ItemsSource = csapatok;
                if (csapatok.Count > 0)
                    cbCsapatok.SelectedIndex = 0;
            }
        }

        private void HozzaadButton_Click(object sender, RoutedEventArgs e)
        {
            string csapat = cbCsapatok.SelectedItem?.ToString();
            string jatekosNev = txtJatekosNev.Text.Trim();

            if (!string.IsNullOrEmpty(csapat) && !string.IsNullOrEmpty(jatekosNev))
            {
                string jatekosAdat = $"{csapat};{jatekosNev}";
                File.AppendAllText(PlayersFile, jatekosAdat + "\n");
                txtJatekosNev.Clear();
                BetoltJatekosok();
                MessageBox.Show("Játékos hozzáadva!");
            }
        }

        private void BetoltButton_Click(object sender, RoutedEventArgs e)
        {
            BetoltJatekosok();
        }

        private void BetoltJatekosok()
        {
            if (File.Exists(PlayersFile))
            {
                List<string> jatekosok = new List<string>(File.ReadAllLines(PlayersFile));
                lbJatekosok.ItemsSource = jatekosok;
            }
        }

        private void BezarButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
